library(dplyr)
library(tidyverse)
library(ggplot2)
library(base)
library(lubridate)

#--------------------Sean Edwards---Line graph to solve question 1--------------------

#changes the data type of the dates to date data type instead of chars
CIS_435_project_data <- mutate(CIS_435_project_data, Date_of_Breach=as.Date(CIS_435_project_data$Date_of_Breach, tryFormats = ("%m/%d/%Y")))

#count number of occurances for each month adn store it in its own tibble
count_by_date <- CIS_435_project_data %>%
  group_by(month=floor_date(Date_of_Breach, "month")) %>%
  tally()

#first plot that shows breaches over time
ggplot(count_by_date, aes(x=count_by_date$month, y=count_by_date$n)) +
  geom_line() +
  ggtitle("Breaches Over Time")+
  ylab("Number of Breaches")+
  xlab("Months")
